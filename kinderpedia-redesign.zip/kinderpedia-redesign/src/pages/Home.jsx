import { Link } from 'react-router-dom'
import { ArrowRight, ShieldCheck, Star, Check } from 'lucide-react'
import { stats, modules, cases, roles } from '../data'

function HeroPath(){
  const nodes=[['done',0],['done',44],['now',10],['lock',-34],['lock',0]]
  return(<div className="relative mx-auto flex w-72 flex-col items-center gap-5 rounded-[2.5rem] border-2 border-b-8 border-slate-200 bg-white p-8 animate-float">
    <div className="w-full"><div className="mb-1 flex justify-between font-display text-sm"><span>Day 1 of your school</span><span className="text-brand-dark">40%</span></div><div className="h-3 rounded-full bg-slate-100"><div className="h-3 w-2/5 rounded-full bg-brand"/></div></div>
    {nodes.map(([s,x],i)=>(<div key={i} style={{transform:`translateX(${x}px)`}} className={`grid h-16 w-16 place-items-center rounded-full border-b-8 font-display text-xl text-white ${s==='done'?'bg-brand border-brand-dark':s==='now'?'bg-sun border-sun-dark text-ink animate-ring':'bg-slate-200 border-slate-300 text-slate-400'}`}>{s==='done'?<Check/>:i+1}</div>))}
  </div>)
}

export default function Home(){
  return(<>
    <section className="bg-gradient-to-b from-sky to-cloud"><div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-[1.2fr_1fr]">
      <div>
        <h1 className="text-5xl font-bold leading-[1.05] md:text-7xl">Run your school like it's the easiest thing you do all day.</h1>
        <p className="mt-6 max-w-xl text-lg text-ink/70">Attendance, grades, billing and parent chat in one calm platform. Live in under 90 days, with a guided path for every person in your community.</p>
        <div className="mt-8 flex flex-wrap gap-4"><Link to="/demo" className="btn btn-sun">Book a free demo</Link><Link to="/journeys" className="btn btn-ghost">Try your path <ArrowRight size={18}/></Link></div>
        <div className="mt-8 flex items-center gap-2 text-sm text-ink/70"><Star className="fill-sun text-sun" size={18}/>Rated 4.9/5 on Capterra, G2 and GetApp</div>
      </div><HeroPath/></div></section>

    <section className="mx-auto -mt-6 grid max-w-6xl gap-4 px-5 md:grid-cols-4">{stats.map(([n,l])=>(<div key={l} className="card text-center"><div className="font-display text-4xl font-bold text-brand-dark">{n}</div><div className="text-sm text-ink/70">{l}</div></div>))}</section>

    <section className="mx-auto mt-24 max-w-6xl px-5">
      <h2 className="max-w-2xl text-4xl font-bold md:text-5xl">Everyone gets a path. Nobody gets lost.</h2>
      <p className="mt-4 max-w-xl text-ink/70">Pick your role and see exactly what your first week looks like.</p>
      <div className="mt-10 grid gap-5 md:grid-cols-3">{Object.entries(roles).map(([k,r])=>(<Link key={k} to={`/journeys?role=${k}`} className="card group hover:-translate-y-1 transition"><div className={`mb-4 h-3 w-16 rounded-full ${k==='director'?'bg-brand':k==='teacher'?'bg-sun':'bg-coral'}`}/><h3 className="text-2xl font-semibold">{r.label}</h3><p className="mt-2 text-ink/70">{r.steps.length} steps, from {r.steps[0][0].toLowerCase()} to {r.steps[4][0].toLowerCase()}.</p><span className="mt-4 inline-flex items-center gap-1 font-display font-semibold text-brand-dark">Start path <ArrowRight size={16}/></span></Link>))}</div>
    </section>

    <section className="mx-auto mt-24 max-w-6xl px-5"><h2 className="text-4xl font-bold md:text-5xl">22 modules. One login.</h2>
      <div className="mt-8 flex flex-wrap gap-3">{modules.map(m=>(<span key={m} className="rounded-2xl border-2 border-b-4 border-slate-200 bg-white px-4 py-2 font-display font-medium">{m}</span>))}</div></section>

    <section className="mx-auto mt-24 max-w-6xl px-5"><h2 className="text-4xl font-bold md:text-5xl">Schools that made the switch</h2>
      <div className="mt-8 grid gap-5 md:grid-cols-3">{cases.map(([n,t])=>(<div key={n} className="card"><div className="font-display text-xl font-semibold">{n}</div><p className="mt-2 text-ink/70">{t}</p></div>))}</div></section>

    <section className="mx-auto mt-24 max-w-6xl px-5"><div className="grid items-center gap-8 rounded-[2.5rem] bg-ink p-10 text-white md:grid-cols-[auto_1fr]"><ShieldCheck size={56} className="text-sun"/><div><h2 className="text-3xl font-bold">Children's data stays private.</h2><p className="mt-2 max-w-2xl text-white/70">Each child's account is visible only to their parents and teachers. Payments run through Stripe. Everything is hosted on AWS.</p></div></div></section>

    <section className="mx-auto mt-24 max-w-3xl px-5 text-center"><h2 className="text-4xl font-bold md:text-5xl">Ready for your first 40 minutes?</h2><p className="mt-4 text-ink/70">See your school inside Kinderpedia, live.</p><Link to="/demo" className="btn btn-sun mt-8">Book a free demo</Link></section>
  </>)
}
